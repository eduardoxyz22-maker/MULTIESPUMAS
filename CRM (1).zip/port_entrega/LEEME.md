# Entrega lista para subir — Dashboard rediseñado (panel.html)

**Ya está todo integrado.** El `generar.py` de esta carpeta es tu script con el bloque
de integración **ya añadido al final** — no tienes que pegar nada.

## Qué subir a la raíz de tu repo (reemplazando / agregando)
1. `generar.py`  → **reemplaza** el que tienes (es el tuyo + el bloque nuevo al final).
2. `dashboard_data.py`  → **nuevo** archivo.
3. `panel.template.html`  → **nuevo** archivo.

## Un cambio más en el workflow
En `.github/workflows/update-crm-dashboard.yml`, donde diga `git add index.html`,
cámbialo a:
```
git add index.html panel.html
```
(Si usa `git add -A` o `git add .`, no cambies nada.)

## Probar
GitHub → pestaña **Actions** → *Actualizar Dashboard CRM Diario* → **Run workflow**.
Al terminar, tu dashboard nuevo queda en:
```
https://eduardoxyz22-maker.github.io/MULTIESPUMAS/panel.html
```
Tu `index.html` clásico sigue igual, intacto.

## Subir por la web (sin terminal)
En tu repo: **Add file → Upload files**, arrastra los 3 archivos, y confirma el commit
(GitHub reemplaza `generar.py` automáticamente porque tiene el mismo nombre).

## Opcional — metas en $ persistentes
Crea un `metas.json` en la raíz con las metas mensuales por vendedora:
```json
{ "Isabel Robledo": 250000, "Maria Flores": 160000, "Mirian Salazar": 160000, "Carola Chavez": 150000 }
```
Si no lo creas, el panel usa un default (~110% del valor del mes) y se puede editar a mano.

## La pestaña Semanal
Sale automática: cierres y $ por semana y por vendedora, mes en curso vs anterior,
calculado desde la fecha de cierre de cada venta (`updated_at` de los leads en
"Compradores"). En junio mostrará Junio vs Mayo solo.

---
Si el primer run marca un error de Python, cópiame el mensaje (suele ser un nombre de
variable distinto en tu versión) y lo ajusto en una línea.
